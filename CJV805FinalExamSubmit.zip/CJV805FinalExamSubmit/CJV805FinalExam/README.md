# Netflix Clone built using React, Redux Toolkit, Firebase, Styled Components, Axios, Node.js, Express and MongoDB.

## Steps to Start the App

+ Install React Dependencies
+ Instal Node Dependencies
+ Start Node App
+ Start React App


## Watch it on [Youtube](https://www.youtube.com/watch?v=HgaJW2I4Mbk)

