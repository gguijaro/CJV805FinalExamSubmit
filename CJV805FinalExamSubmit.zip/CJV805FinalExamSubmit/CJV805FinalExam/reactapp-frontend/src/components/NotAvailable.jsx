import React from "react";

export default function NotAvailable() {
  return (
    <h1 className="not-available">
      Movies in this genre are currently unavailable. Please choose a different genre.
    </h1>
  );
}
