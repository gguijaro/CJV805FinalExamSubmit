import React from "react";
import styled from "styled-components";
import CardSlider from "./CardSlider";
export default function Slider({ movies }) {
  const getMoviesFromRange = (from, to) => {
    return movies.slice(from, to);
  };
  return (
    <Container>
      <CardSlider data={getMoviesFromRange(0, 10)} title="Main Attraction" />
      <CardSlider data={getMoviesFromRange(10, 20)} title="Trending" />
      <CardSlider
        data={getMoviesFromRange(20, 30)}
        title="Family Favorites"
      />
      <CardSlider
        data={getMoviesFromRange(30, 40)}
        title="Popular"
      />
      <CardSlider data={getMoviesFromRange(40, 50)} title="Coming Soon" />
      <CardSlider data={getMoviesFromRange(50, 60)} title="Promotion" />
    </Container>
  );
}

const Container = styled.div``;
