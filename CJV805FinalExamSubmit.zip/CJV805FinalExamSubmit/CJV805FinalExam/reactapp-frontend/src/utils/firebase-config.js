import { getAuth } from "firebase/auth";
import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyBY0jtKGeM51TtA_B8ZzmAvalAyboBbtZI",
  authDomain: "reactapp-9e151.firebaseapp.com",
  projectId: "reactapp-9e151",
  storageBucket: "reactapp-9e151.appspot.com",
  messagingSenderId: "764009902417",
  appId: "1:764009902417:web:7d393674e5d24f6f37a370",
  measurementId: "G-BMN0VJSV8Q"
};

const app = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(app);
