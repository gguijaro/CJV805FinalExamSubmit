export const API_KEY =  "d06205f8e91308dc38bba34fec612f17"
export const TMDB_BASE_URL = "https://api.themoviedb.org/3"
